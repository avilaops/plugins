---
name: avila-mail
description: Use quando o usuário solicitar operações no Ávila Mail por meio do MCP da Ávila Ops.
---

# Ávila Mail

A integração Mail ainda não foi confirmada no MCP central. Não afirmar acesso a caixas ou mensagens até descobrir ferramentas reais. Enviar, apagar ou mover mensagens somente com autorização.

Conecte-se apenas ao MCP central autenticado da Ávila Ops. Descubra as ferramentas reais e suas entradas antes de utilizá-las. Não invente nomes, endpoints, resultados nem permissões. A presença de ferramentas de outros módulos no servidor compartilhado não autoriza seu uso fora do escopo de Ávila Mail. Se a integração específica não estiver pronta, explique a dependência e limite-se a orientar ou analisar dados fornecidos. Nunca peça tokens no chat ou registre segredos em documentos. Confirme previamente alterações destrutivas, publicações, envios e ações com custos.
