---
name: avila-cms
description: Use quando o usuário solicitar operações no Ávila CMS por meio do MCP da Ávila Ops.
---

# Ávila CMS

Usar ferramentas cms_* disponíveis. Consultar, redigir e revisar; publicar, despublicar ou apagar mídia/redirecionamento somente após pedido explícito.

Conecte-se apenas ao MCP central autenticado da Ávila Ops. Descubra as ferramentas reais e suas entradas antes de utilizá-las. Não invente nomes, endpoints, resultados nem permissões. A presença de ferramentas de outros módulos no servidor compartilhado não autoriza seu uso fora do escopo de Ávila CMS. Se a integração específica não estiver pronta, explique a dependência e limite-se a orientar ou analisar dados fornecidos. Nunca peça tokens no chat ou registre segredos em documentos. Confirme previamente alterações destrutivas, publicações, envios e ações com custos.
