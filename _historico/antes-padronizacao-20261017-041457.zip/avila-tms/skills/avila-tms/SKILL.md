---
name: avila-tms
description: Use quando o usuário solicitar operações no Ávila TMS por meio do MCP da Ávila Ops.
---

# Ávila TMS

O adaptador TMS está pendente. As ferramentas fiscal_* não equivalem a integração TMS geral. Não supor acesso a cargas, motoristas ou entregas.

Conecte-se apenas ao MCP central autenticado da Ávila Ops. Descubra as ferramentas reais e suas entradas antes de utilizá-las. Não invente nomes, endpoints, resultados nem permissões. A presença de ferramentas de outros módulos no servidor compartilhado não autoriza seu uso fora do escopo de Ávila TMS. Se a integração específica não estiver pronta, explique a dependência e limite-se a orientar ou analisar dados fornecidos. Nunca peça tokens no chat ou registre segredos em documentos. Confirme previamente alterações destrutivas, publicações, envios e ações com custos.
