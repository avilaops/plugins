---
name: avila-crm
description: Use quando o usuário solicitar operações no Ávila CRM por meio do MCP da Ávila Ops.
---

# Ávila CRM

O adaptador CRM do MCP central ainda consta como pendente. Não simular operações nem confundir contato_buscar do WhatsApp com cadastro CRM.

Conecte-se apenas ao MCP central autenticado da Ávila Ops. Descubra as ferramentas reais e suas entradas antes de utilizá-las. Não invente nomes, endpoints, resultados nem permissões. A presença de ferramentas de outros módulos no servidor compartilhado não autoriza seu uso fora do escopo de Ávila CRM. Se a integração específica não estiver pronta, explique a dependência e limite-se a orientar ou analisar dados fornecidos. Nunca peça tokens no chat ou registre segredos em documentos. Confirme previamente alterações destrutivas, publicações, envios e ações com custos.
