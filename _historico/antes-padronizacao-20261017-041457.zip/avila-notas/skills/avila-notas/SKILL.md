---
name: avila-notas
description: Use quando o usuário solicitar operações no Ávila Notas por meio do MCP da Ávila Ops.
---

# Ávila Notas

Consultar documentação e coleções; criar ou editar documentos apenas quando solicitado. A conexão do Notas aparece no n8n por https://notas.avilaops.com/mcp. Excluir apenas com autorização explícita.

Conecte-se apenas ao MCP central autenticado da Ávila Ops. Descubra as ferramentas reais e suas entradas antes de utilizá-las. Não invente nomes, endpoints, resultados nem permissões. A presença de ferramentas de outros módulos no servidor compartilhado não autoriza seu uso fora do escopo de Ávila Notas. Se a integração específica não estiver pronta, explique a dependência e limite-se a orientar ou analisar dados fornecidos. Nunca peça tokens no chat ou registre segredos em documentos. Confirme previamente alterações destrutivas, publicações, envios e ações com custos.
