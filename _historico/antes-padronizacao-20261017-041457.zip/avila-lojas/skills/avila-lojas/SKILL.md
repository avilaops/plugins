---
name: avila-lojas
description: Use quando o usuário solicitar operações no Ávila Lojas por meio do MCP da Ávila Ops.
---

# Ávila Lojas

Usar lojas_* existentes; identificar tenant antes de cada operação e não misturar dados entre lojas. Etiquetas podem cobrar valores; mudanças de status podem notificar clientes. Excluir, publicar, cancelar somente mediante pedido explícito.

Conecte-se apenas ao MCP central autenticado da Ávila Ops. Descubra as ferramentas reais e suas entradas antes de utilizá-las. Não invente nomes, endpoints, resultados nem permissões. A presença de ferramentas de outros módulos no servidor compartilhado não autoriza seu uso fora do escopo de Ávila Lojas. Se a integração específica não estiver pronta, explique a dependência e limite-se a orientar ou analisar dados fornecidos. Nunca peça tokens no chat ou registre segredos em documentos. Confirme previamente alterações destrutivas, publicações, envios e ações com custos.
